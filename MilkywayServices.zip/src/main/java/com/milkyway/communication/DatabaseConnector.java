package com.milkyway.communication;

public class DatabaseConnector {

	public void getDBconnection() {
		// TODO Auto-generated method stub
		
	}

}
