Milky Way services project defines the interface for all the RestFul web services.
